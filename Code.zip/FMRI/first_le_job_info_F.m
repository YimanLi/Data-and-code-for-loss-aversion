function first_le_job_info_F(s,onset,FD_Scans,dir,onset_solo,onset_mix)
%-----------------------------------------------------------------------
% Job saved on 26-Aug-2020 22:07:04 by cfg_util (rgain $Rgain: 7345 $)
% spm SPM - SPM12 (7487)
% cfg_basicio BasicIO - Unknown
%-----------------------------------------------------------------------
matlabbatch{1}.spm.stats.fmri_spec.dir = {dir};
matlabbatch{1}.spm.stats.fmri_spec.timing.units = 'secs';
matlabbatch{1}.spm.stats.fmri_spec.timing.RT = 1;
matlabbatch{1}.spm.stats.fmri_spec.timing.fmri_t = 65;
matlabbatch{1}.spm.stats.fmri_spec.timing.fmri_t0 = 33;
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(1).scans = s{1};
onset_run1=onset(1,:);
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(1).name = 'Info';
%%
onset_run1=onset(1,:);
matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(1).onset = [onset_run1{1}(:,2)];
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(1).duration = 0;
matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(1).tmod = 0;
matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(1).pmod = struct('name', {}, 'param', {}, 'poly', {});
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(1).orth = 1;

matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(2).name = 'solo';
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(2).onset = [onset_solo{1}];
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(2).duration = 0;
matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(2).tmod = 0;
matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(2).pmod = struct('name', {}, 'param', {}, 'poly', {});
matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(2).orth = 1;

matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(3).name = 'mix';
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(3).onset = [onset_mix{1}];
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(3).duration = 0;
matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(3).tmod = 0;
matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(3).pmod = struct('name', {}, 'param', {}, 'poly', {});
matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(3).orth = 1;
matlabbatch{1}.spm.stats.fmri_spec.sess(1).multi = {''};
matlabbatch{1}.spm.stats.fmri_spec.sess(1).regress = struct('name', {}, 'val', {});
matlabbatch{1}.spm.stats.fmri_spec.sess(1).multi_reg ={FD_Scans{1}};
matlabbatch{1}.spm.stats.fmri_spec.sess(1).hpf = 128;
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(2).scans = s{2};
onset_run2=onset(2,:);
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(1).name = 'Info';
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(1).onset = [onset_run2{1}(:,2)];
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(1).duration = 0;
matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(1).tmod = 0;
matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(1).pmod = struct('name', {}, 'param', {}, 'poly', {});
matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(1).orth = 1;

matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(2).name = 'solo';
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(2).onset = [onset_solo{2}];
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(2).duration = 0;
matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(2).tmod = 0;
matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(2).pmod = struct('name', {}, 'param', {}, 'poly', {});
matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(2).orth = 1;
matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(3).name = 'mix';
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(3).onset = [onset_mix{2}];
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(3).duration = 0;
matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(3).tmod = 0;
matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(3).pmod = struct('name', {}, 'param', {}, 'poly', {});
matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(3).orth = 1;
matlabbatch{1}.spm.stats.fmri_spec.sess(2).multi = {''};
matlabbatch{1}.spm.stats.fmri_spec.sess(2).regress = struct('name', {}, 'val', {});
matlabbatch{1}.spm.stats.fmri_spec.sess(2).multi_reg = {FD_Scans{2}};
matlabbatch{1}.spm.stats.fmri_spec.sess(2).hpf = 128;
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(3).scans = s{3};
onset_run3=onset(3,:);
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(1).name = 'Info';
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(1).onset = [onset_run3{1}(:,2)];
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(1).duration = 0;
matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(1).tmod = 0;
matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(1).pmod = struct('name', {}, 'param', {}, 'poly', {});
matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(1).orth = 1;
matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(2).name = 'solo';
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(2).onset = [onset_solo{3}];
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(2).duration = 0;
matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(2).tmod = 0;
matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(2).pmod = struct('name', {}, 'param', {}, 'poly', {});
matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(2).orth = 1;
matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(3).name = 'mix';
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(3).onset = [onset_mix{3}];
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(3).duration = 0;
matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(3).tmod = 0;
matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(3).pmod = struct('name', {}, 'param', {}, 'poly', {});
matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(3).orth = 1;
matlabbatch{1}.spm.stats.fmri_spec.sess(3).multi = {''};
matlabbatch{1}.spm.stats.fmri_spec.sess(3).regress = struct('name', {}, 'val', {});
matlabbatch{1}.spm.stats.fmri_spec.sess(3).multi_reg = {FD_Scans{3}};
matlabbatch{1}.spm.stats.fmri_spec.sess(3).hpf = 128;
matlabbatch{1}.spm.stats.fmri_spec.fact = struct('name', {}, 'lgainels', {});
matlabbatch{1}.spm.stats.fmri_spec.bases.hrf.derivs = [0 0];
matlabbatch{1}.spm.stats.fmri_spec.volt = 1;
matlabbatch{1}.spm.stats.fmri_spec.global = 'None';
matlabbatch{1}.spm.stats.fmri_spec.mthresh = 0.8;
matlabbatch{1}.spm.stats.fmri_spec.mask = {''};
matlabbatch{1}.spm.stats.fmri_spec.cvi = 'AR(1)';
matlabbatch{2}.spm.stats.fmri_est.spmmat(1) = cfg_dep('fMRI model specification: SPM.mat File', substruct('.','val', '{}',{1}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('.','spmmat'));
matlabbatch{2}.spm.stats.fmri_est.write_residuals = 0;
matlabbatch{2}.spm.stats.fmri_est.method.Classical = 1;
matlabbatch{3}.spm.stats.con.spmmat(1) = cfg_dep('Model estimation: SPM.mat File', substruct('.','val', '{}',{2}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('.','spmmat'));
matlabbatch{3}.spm.stats.con.consess{1}.fcon.name = 'F';
matlabbatch{3}.spm.stats.con.consess{1}.fcon.weights = [1/3 0 0 0 0 0 0 0 0 1/3 0 0 0 0 0 0 0 0 1/3 0 0 0 0 0 0 0 0
                                                        0 1/3 0 0 0 0 0 0 0 0 1/3 0 0 0 0 0 0 0 0 1/3 0 0 0 0 0 0 0
                                                        0 0 1/3 0 0 0 0 0 0 0 0 1/3 0 0 0 0 0 0 0 0 1/3 0 0 0 0 0 0];
matlabbatch{3}.spm.stats.con.consess{1}.fcon.sessrep = 'none';
matlabbatch{3}.spm.stats.con.delete = 1;
spm_jobman('run',matlabbatch);