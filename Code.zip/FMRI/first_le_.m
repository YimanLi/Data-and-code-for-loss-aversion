
% List of open inputs
clc
clear

%%
funcdata_path = 'H:\czdata\FunImg';
cd (funcdata_path);   
sub_list=dir ('S*');  
for i =1:size(sub_list,1) 
    subj(i,:) = sub_list(i).name; 
end
subj = cellstr(subj);
sess = {'2_ep2d_bold_task_run1' '3_ep2d_bold_task_run2' '4_ep2d_bold_task_run3'}; %write your session based on task fmri design
%%   swraf.nii
for Si = 1:length(subj)
    %%
    fun_scans = cell(1,length(sess));
    for Ti = 1:length(sess)   
        run_path = fullfile(funcdata_path,subj{Si},sess{Ti});
        run_files = dir(fullfile(run_path,'swraf*.nii'));
        sess_scans = [];
        for i = 1:length(run_files)
        sess_scans{i,1} = strcat(run_path,'\',[run_files(i).name],',1');
        end
        fun_scans{1,Ti} = sess_scans;
    end 

    scans(Si,:)=fun_scans(1,:);
   
end
%%    rp.txt

  cd H:\czdata\code
for Si = 1:length(subj)    
    for Ti = 1:length(sess)   
        run_path = fullfile(funcdata_path,subj{Si},sess{Ti});
        run_files = dir(fullfile(run_path,'rp*.txt'));
        F_scans = strcat(run_path,'\',[run_files.name]);
         [mfd(Si,Ti),hfd(Si,Ti)] = wgr_mean_FD(F_scans);
         fd_scans{1,Ti} = F_scans;
    end
    hfd(Si,4)=sum(hfd(Si,:),2);
    FD_scans(Si,:)=fd_scans(1,:);
end 
  
  for i=1:3%�г���20%��ʱ����hfdֵ������0.5   ���ݿ��Բ�Ҫ��
  bad_sub{i}=find(hfd(:,i)>658*0.2);
  end
%%


  cd D:\anxiety\pro\mm\four_fmri_2.0\Data\behavior
  %load condition.mat
  load condition_st.mat
  %load condition_ocu.mat
  %load condition_direction.mat
 % load condition_co_mix.mat
 %load condition_info_mix.mat
%%   make dir
work_dir= 'H:\czdata'; 
raw_dir=[work_dir, '\FunImg']; 
nifti_dir = [work_dir, '\first_level\single_trail_2'];
cd (raw_dir);   
sub_list=dir ('S*');  

for i =1:size(sub_list,1) 
    subID_list(i,:) = sub_list(i).name; 
end
subID_list = cellstr(subID_list);
for folder=1:size(subID_list,1)
    folderdir{folder}=[ nifti_dir, '\', sprintf(subID_list{folder})]; 
    mkdir(fullfile(folderdir{folder}));     	%create folders of functional data
end
 
%%
 cd H:\czdata\code
 nrun=52;

for crun = 1:nrun
    s=scans(crun,:);
    FD_Scans=FD_scans(crun,:);
    %first_le_job_sr_mix(s,condition{crun},FD_Scans,folderdir{crun});
    first_le_job_con_mix(s,condition_info_c{crun},condition_mix{crun},condition_solo{crun},FD_Scans,folderdir{crun},condition_info_nc{crun});
    %first_le_job(s,condition{crun},FD_Scans,p3{crun},p4{crun},folderdir{crun});
    %first_le_job_info(s,condition_info{crun},FD_Scans,U_ocu{crun},U_solo{crun},folderdir{crun},condition_solo{crun},condition_mix{crun});
   %first_le_job_direction(s,condition_info_c{crun},condition_info_nc{crun},FD_Scans,U_ocu{crun},U_solo{crun},folderdir{crun},direction{crun},direction_m{crun},condition_solo_mix{crun});
end

%%
 nrun=52;
for crun=8 %31:40;
    for r=1 %1:3
         s=scans(crun,r);
         FD_Scans=FD_scans(crun,r);
          for st=108   %1:length(condition_st{crun}{r,1})
              cd H:\czdata\code
              condition_s=condition_st{crun}{r,1}(st,1);
              condition_o=condition_st{crun}{r,1};
              condition_o(st,:)=[];
              first_le_job_st(s,condition_s,condition_o,FD_Scans,folderdir{crun});
              cd(folderdir{crun})
              movefile('beta_0001.nii', ['beta_st_',num2str(r),'_',num2str(st(1,1)),'.nii']);
              delete('SPM.mat')
          end
    end
end
%%
 nrun=52;   
 cd H:\czdata\code
for crun=1:nrun;
         s=scans(crun,:);
         FD_Scans=FD_scans(crun,:);
         first_le_job_st_one(s,condition_st{crun},FD_Scans,folderdir{crun});
end
%%    �������ļ�
clc
clear

sub_Node_list=dir ('Schaefer_7N_*'); 
for i =1:size(sub_Node_list,1) 
    subID_list(i,:) =cellstr(sub_Node_list(i).name); 
    if length(subID_list{i})==21
        subID_new_list{i}=[subID_list{i}(1:12),'00',subID_list{i}(13:end)];
        movefile(subID_list{i},subID_new_list{i});
    elseif length(subID_list{i})==22
         subID_new_list{i}=[subID_list{i}(1:12),'0',subID_list{i}(13:end)];
         movefile(subID_list{i},subID_new_list{i});
    elseif length(subID_list{i})==23
         subID_new_list{i}=subID_list{i};    
    end
end

clc
clear
work_dir= 'H:\czdata'; 
raw_dir=[work_dir, '\FunImg']; 
nifti_dir = [work_dir, '\first_level\single_trail'];
cd (raw_dir);   
sub_list=dir ('S*');  
for i=1:52
work_dir= 'H:\czdata\first_level\single_trail';
raw_dir=[work_dir, '\',sub_list(i).name]; 
cd (raw_dir);   
sub_list_beta=dir ('beta_st_*.nii');  
for i =1:size(sub_list_beta,1) 
    subID_list(i,:) =cellstr(sub_list_beta(i).name); 
    if length(subID_list{i})==15
        subID_new_list{i}=[subID_list{i}(1:10),'00',subID_list{i}(11:end)];
        movefile(subID_list{i},subID_new_list{i});
    elseif length(subID_list{i})==16
         subID_new_list{i}=[subID_list{i}(1:10),'0',subID_list{i}(11:end)];
         movefile(subID_list{i},subID_new_list{i});
    elseif length(subID_list{i})==17
         subID_new_list{i}=subID_list{i};    
    end
end
end
%%
clear
clc
%%     ���betaֵ����
path='D:\anxiety\pro\mm\four_fmri_2.0\Data\behavior';
cd(path) 
load condition_st.mat
work_dir= 'H:\czdata'; 
raw_dir=[work_dir, '\FunImg']; 
nifti_dir = [work_dir, '\first_level\single_trail'];
cd (raw_dir);   
sub_list=dir ('S*');  

for i=1:52
work_dir= 'H:\czdata\first_level\single_trail_2';
raw_dir=[work_dir, '\',sub_list(i).name]; 
cd (raw_dir);   
sub_list_beta=dir ('beta_st_*.nii');  
l(i,1)=length(sub_list_beta);
l(i,2)=length(condition_st{i}{1})+length(condition_st{i}{2})+length(condition_st{i}{3});
  for t =1:size(sub_list_beta,1) 
   a1(t,1)=str2num(sub_list_beta(t).name(9));
  end
  
   if length(find(a1==1))==length(condition_st{i}{1})
     de(i,1)=0;
   else
     de(i,1)=1;
   end
    if length(find(a1==2))==length(condition_st{i}{2})
     de(i,2)=0;
   else
     de(i,2)=1;
   end
    if length(find(a1==3))==length(condition_st{i}{3})
     de(i,3)=0;
   else
     de(i,3)=1;
    end
   clear a1
end