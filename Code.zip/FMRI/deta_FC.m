clear 
clc 
cd K:\czdata\beta
load('condition_st.mat') 
load('1_10.mat', 'Y') 
load('11_30.mat', 'Y') 
load('31_52.mat', 'Y') 
Y_1_10(:,[13 118 123 203 320 374])=[]; 
Y_31_52(:,[13 118 119 120 125 175 206 376]); 
Y_31_52(:,[13 118 119 120 125 175 206 376])=[]; 
Y=[Y_1_10;Y_11_30;Y_31_52]; 

path='D:\anxiety\pro\mm\four_fmri_2.0\Data\behavior'; 
cd(path) 
s=1;
 for i=1:52 
 for r=1:3 
 for c=1:4 
 Beta{i}{r,c}=Y(s:s-1+length(condition{i}{r,c}),:); 
 if i<52
 s=s+length(condition{i}{r,c}); 
 end
 end 
 end
 end
 
 for i=1:52
     for c=1:4   %1solo;2Mix;3Ssfe;4Risk
        beta{i}{c}=[Beta{i}{1,c};Beta{i}{2,c};Beta{i}{3,c}]; 
        beta_fc{i}{c}=corr(beta{i}{c});  
        beta_FC{c}(i,:)=tri_oneD(beta_fc{i}{c});
     end    
 end
 
 for c=1:4
      beta_FC{c}(11,:)=[];
 end
 
 R = UMAT(beta_FC{1},par(:,1));
%%    PPI ���ڷ���
for i=1:3 %i=FC
    FC{i}(:,1)=Y1(:,i);
    FC{i}(:,2)=Y2(:,i);
    FC{i}(:,3)=Y3(:,i);
end   
Insula_TPJ=mean([mean(FC{1},2),mean(FC{2},2),mean(FC{1},2)],2);%ÿ��runƽ��֮������ROIƽ��
Insula_TPJ(11,:)=[];
FC=Insula_TPJ-mean(Insula_TPJ);
find(Insula_TPJ<mean(Insula_TPJ)-3*std(Insula_TPJ))
B2=B;
B2([11],:)=[];
for i=1:5
    B2(:,i)=B2(:,i)-mean(B2(:,i));  % con_R con_S con_All dec_info lambda
end

B2(:,6)=FC.*B2(:,5);


save FC_Insula_TPJ.mat

for i=1:5
    B3(:,i)=B2(:,i)-mean(B2(:,i));
end

%%   Direction
FC=mean([Y1,Y2,Y3],2); %����runƽ��
FC(11,:)=[];
FC=FC-mean(FC); %%dmean
B1=B;
B1([11 25],:)=[];
for i=1:5
    B1(:,i)=B1(:,i)-mean(B1(:,i));  % con_R con_S con_All dec_info lambda
end

B1(:,6)=FC.*B1(:,5);

load M.mat   % M:con_R con_S con_All dec_info rho ocu lambda 
for i=1:7
    extre{1,i}=find(M(:,i)>mean(M(:,i)+3*std(M(:,i))));  
    extre{2,i}=find(M(:,i)<mean(M(:,i)-3*std(M(:,i))));
end
extre{1,8}=find(FC_D>mean(FC_D+3*std(FC_D)));
extre{1,9}=find(FC_Uocu>mean(FC_Uocu+3*std(FC_Uocu)));
extre{2,8}=find(FC_D<mean(FC_D-3*std(FC_D)));
extre{2,9}=find(FC_Uocu<mean(FC_Uocu-3*std(FC_Uocu)));
M_D=M;
M_D([11 25],:)=[];
FC_D(,:)=[];
M_Uocu=M;
M_Uocu([11],:)=[];
FC_Uocu(,:)=[];


%%    
cd K:\czdata\beta\node_direction_lambda
load Insula_conform.mat
 
Insula_L(:,1)=mean([Y1(:,1),Y2(:,1)],2);% X=-31
Insula_R(:,1)=mean([Y1(:,2),Y2(:,2)],2);% X= 35
Insula_L(11,:)=[];
Insula_R(11,:)=[];


[a,order]=sort(lambda);
highl_o=order(1:25,:);
lowl_o=order(26:51,:);
D_r_h=Distance_risk(highl_o,:);
D_s_h=Distance_safe(highl_o,:);
D_r_l=Distance_risk(lowl_o,:);
D_s_l=Distance_safe(lowl_o,:);
[th ph]=ttest(D_r_h,D_s_h)
[tl pl]=ttest(D_r_l,D_s_l)
%%   direction*lambda  Insula�º����
cd K:\czdata\beta\node_direction_lambda
load('con_safe_risk_Insula.mat')
for i=1:2 %i=roi Insula -31 35  dacc
    for r=1:3 %run
    ROI_safe{i}(:,r)=safe_{r}(:,i);
    %ROI_risk{i}(:,r)=risk_{r}(:,i);
    end 
    ROI_safe{i}(11,:)=[];
    %ROI_risk{i}(11,:)=[];
end   
Insula_L_safe=mean(ROI_safe{1},2);
Insula_R_safe=mean(ROI_safe{2},2);
dacc_safe=mean(ROI_safe{3},2);
Insula_L_risk=mean(ROI_risk{1},2);
Insula_R_risk=mean(ROI_risk{2},2);
dacc_risk=mean(ROI_risk{3},2);
Insula_safe=mean([Insula_L_safe,Insula_R_safe],2);
Insula_risk=mean([Insula_L_risk,Insula_R_risk],2);
lambda([5 11 21  24  25  28 50],:)=[];

[a,order]=sort(lambda);
%two group
lowl_o=order(1:23,:);
highl_o=order(24:45,:);
%three group
hlo1=order(1:15,:);
hlo2=order(16:30,:);
hlo3=order(31:45,:);
%  �Ž�R��ͼ https://stackoverflow.com/questions/35717353/split-violin-plot-with-ggplot2
%two group
ttest_h=[Insula_risk(highl_o,:),Insula_safe(highl_o,:),dacc_risk(highl_o,:),dacc_safe(highl_o,:)];
ttest_l=[Insula_risk(lowl_o,:),Insula_safe(lowl_o,:),dacc_risk(lowl_o,:),dacc_safe(lowl_o,:)];
%three group
ttest_1=[Insula_risk(hlo1,:),Insula_safe(hlo1,:),dacc_risk(hlo1,:),dacc_safe(hlo1,:)];
ttest_2=[Insula_risk(hlo2,:),Insula_safe(hlo2,:),dacc_risk(hlo2,:),dacc_safe(hlo2,:)];
ttest_3=[Insula_risk(hlo3,:),Insula_safe(hlo3,:),dacc_risk(hlo3,:),dacc_safe(hlo3,:)];

y_Insula=[ttest_h(:,1);ttest_h(:,2);ttest_l(:,1);ttest_l(:,2)];
y_dacc=[ttest_h(:,3);ttest_h(:,4);ttest_l(:,3);ttest_l(:,4)];
y_PPI=[ttest_h(:,1);ttest_h(:,2);ttest_l(:,1);ttest_l(:,2)];
x=[ones(46,1);ones(44,1)*2]
m=[ones(23,1);ones(23,1)*2;ones(22,1);ones(22,1)*2]
%
Distance([5 11 21  24  25  28 50],:)=[];
D_h(:,1)=Distance(highl_o,1);%high risk
D_h(:,2)=Distance(highl_o,2);%high safe
D_l(:,1)=Distance(lowl_o,1);%low risk
D_l(:,2)=Distance(lowl_o,2);%low safe
save con_safe_risk_result.mat
%PPI
cd K:\czdata\beta\node_PPI_direction_lambda
load PPI_TPJ_risk_safe.mat
i=1
    for r=1:3 %run
    ROI_safe{i}(:,r)=safe_{r}(:,i);
    %ROI_risk{i}(:,r)=risk_{r}(:,i);
    end 
    ROI_safe{i}(11,:)=[];
    ROI_risk{i}(11,:)=[];
Insula_TPJ_safe=mean(ROI_safe{1},2);
Insula_TPJ_risk=mean(ROI_risk{1},2);  
find(Insula_TPJ_safe<mean(Insula_TPJ_safe)-3*std(Insula_TPJ_safe))
find(Insula_TPJ_safe>mean(Insula_TPJ_safe)+3*std(Insula_TPJ_safe))
find(Insula_TPJ_risk>mean(Insula_TPJ_risk)+3*std(Insula_TPJ_risk))
find(Insula_TPJ_risk<mean(Insula_TPJ_risk)-3*std(Insula_TPJ_risk))
lambda([5 11 21  24  25  28 50],:)=[];

[a,order]=sort(lambda);
lowl_o=order(1:22,:);
highl_o=order(23:45,:);
lambda(lowl_o,:)
lambda(highl_o,:)

ttest_h=[Insula_TPJ_risk(highl_o,:),Insula_TPJ_safe(highl_o,:)];
ttest_l=[Insula_TPJ_risk(lowl_o,:),Insula_TPJ_safe(lowl_o,:)];

Distance([5 11 21  24  25  28 50],:)=[];
D_h(:,1)=Distance(highl_o,1);%high risk
D_h(:,2)=Distance(highl_o,2);%high safe
D_l(:,1)=Distance(lowl_o,1);%low risk
D_l(:,2)=Distance(lowl_o,2);%low safe
save con_PPI_safe_risk_result.mat   

%%  Info Uocu lambda �º����

for i=1:7 %i=roi Insula -32 36  dacc -1  striatum-11 -14 12 29
     for r=1:3 %run
    FC_{i}(:,r)=FC{r}(:,i);
    end 
   FC_{i}(11,:)=[];
   FC_mean(:,i)=mean(FC_{i},2);
end   
Insula=mean(FC_mean(:,1:2),2);
striatum=mean(FC_mean(:,4:7),2);
dacc=FC_mean(:,3);

find(FC_mean>mean(FC_mean)+3*std(FC_mean))
find(FC_mean<mean(FC_mean)-3*std(FC_mean))

lambda(11,:)=[];

save beta_Info_ocu_lambda.mat



for i=1:52
 a(i,1)=length(distance_safe{i}{1,3});
end




%% AI-TPJ
load lambda.mat
load AI_TPJ_3mm.mat
Fc_safe(:,1)=Y_safe([1:46],1);
Fc_safe(:,2)=Y_safe([47:92],1);
Fc_safe(:,3)=Y_safe([93:138],1);
Fc_risk(:,1)=Y_risk([1:46],1);
Fc_risk(:,2)=Y_risk([47:92],1);
Fc_risk(:,3)=Y_risk([93:138],1);

beta_safe=mean(Fc_safe,2);
beta_risk=mean(Fc_risk,2);
beta_safe(11,:)=[];
beta_risk(11,:)=[];

lambda([5 11 21  24  25  28 50],:)=[];
[a,order]=sort(lambda);
lowl_o=order(1:22,:);
highl_o=order(23:45,:);

beta_AI_TPJ_safe=beta_safe(order,:);
beta_AI_TPJ_risk=beta_risk(order,:);
lambda=lambda(order,:);
save beta_3mm.mat

FC_mean=beta_AI_TPJ_risk;
find(FC_mean>mean(FC_mean)+3*std(FC_mean))
find(FC_mean<mean(FC_mean)-3*std(FC_mean))