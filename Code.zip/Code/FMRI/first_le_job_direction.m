function first_le_job_direction(s,onset,onset_nc,FD_Scans,P1,P2,dir,di,di_m,onset_solo_mix)
%-----------------------------------------------------------------------
% Job saved on 26-Aug-2020 22:07:04 by cfg_util (rgain $Rgain: 7345 $)
% spm SPM - SPM12 (7487)
% cfg_basicio BasicIO - Unknown
%-----------------------------------------------------------------------
matlabbatch{1}.spm.stats.fmri_spec.dir = {dir};
matlabbatch{1}.spm.stats.fmri_spec.timing.units = 'secs';
matlabbatch{1}.spm.stats.fmri_spec.timing.RT = 1;
matlabbatch{1}.spm.stats.fmri_spec.timing.fmri_t = 65;
matlabbatch{1}.spm.stats.fmri_spec.timing.fmri_t0 = 33;
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(1).scans = s{1};
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(1).name = 'Info_con';
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(1).onset = [onset{1}];
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(1).duration = 0;
matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(1).tmod = 0;

matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(1).pmod(1).name = 'U_ocu';
%%
P1_run1=P1(:,1);
P2_run1=P2(:,1);
matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(1).pmod(1).param = [P1_run1{1}];
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(1).pmod(1).poly = 1;
matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(1).pmod(2).name = 'U_solo';
%%

matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(1).pmod(2).param = [P2_run1{1}];
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(1).pmod(2).poly = 1;
matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(1).pmod(3).name = 'direction';
%%

matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(1).pmod(3).param = [di{1}];
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(1).pmod(3).poly = 1;
matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(1).pmod(4).name = 'direction_m';
%%

matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(1).pmod(4).param = [di_m{1}];
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(1).pmod(4).poly = 1;

matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(1).orth = 1;

matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(2).name = 'solo_mix';
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(2).onset = [onset_solo_mix{1}];
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(2).duration = 0;
matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(2).tmod = 0;
matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(2).pmod = struct('name', {}, 'param', {}, 'poly', {});
matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(2).orth = 1;

matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(3).name = 'not_conform';
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(3).onset = [onset_nc{1}];
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(3).duration = 0;
matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(3).tmod = 0;
matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(3).pmod = struct('name', {}, 'param', {}, 'poly', {});
matlabbatch{1}.spm.stats.fmri_spec.sess(1).cond(3).orth = 1;

matlabbatch{1}.spm.stats.fmri_spec.sess(1).multi = {''};
matlabbatch{1}.spm.stats.fmri_spec.sess(1).regress = struct('name', {}, 'val', {});
matlabbatch{1}.spm.stats.fmri_spec.sess(1).multi_reg ={FD_Scans{1}};
matlabbatch{1}.spm.stats.fmri_spec.sess(1).hpf = 128;
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(2).scans = s{2};

%%
matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(1).name = 'Info_con';
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(1).onset = [onset{2}];
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(1).duration = 0;
matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(1).tmod = 0;
matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(1).pmod(1).name = 'U_ocu';
%%
P1_run2=P1(:,2);
P2_run2=P2(:,2);
matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(1).pmod(1).param = [P1_run2{1}];
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(1).pmod(1).poly = 1;
matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(1).pmod(2).name = 'U_solo';
%%

matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(1).pmod(2).param = [P2_run2{1}];
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(1).pmod(2).poly = 1;
matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(1).pmod(3).name = 'direction';
%%

matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(1).pmod(3).param = [di{2}];
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(1).pmod(3).poly = 1;
matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(1).pmod(4).name = 'direction_m';
%%

matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(1).pmod(4).param = [di_m{2}];
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(1).pmod(4).poly = 1;
matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(1).orth = 1;
matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(2).name = 'solo_mix';
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(2).onset = [onset_solo_mix{2}];
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(2).duration = 0;
matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(2).tmod = 0;
matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(2).pmod = struct('name', {}, 'param', {}, 'poly', {});
matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(2).orth = 1;

matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(3).name = 'not_conform';
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(3).onset = [onset_nc{2}];
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(3).duration = 0;
matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(3).tmod = 0;
matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(3).pmod = struct('name', {}, 'param', {}, 'poly', {});
matlabbatch{1}.spm.stats.fmri_spec.sess(2).cond(3).orth = 1;

matlabbatch{1}.spm.stats.fmri_spec.sess(2).multi = {''};
matlabbatch{1}.spm.stats.fmri_spec.sess(2).regress = struct('name', {}, 'val', {});
matlabbatch{1}.spm.stats.fmri_spec.sess(2).multi_reg = {FD_Scans{2}};
matlabbatch{1}.spm.stats.fmri_spec.sess(2).hpf = 128;
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(3).scans = s{3};
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(1).name = 'Info_con';
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(1).onset = [onset{3}];
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(1).duration = 0;
matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(1).tmod = 0;
matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(1).pmod(1).name = 'U_ocu';
%%
P1_run3=P1(:,3);
P2_run3=P2(:,3);
matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(1).pmod(1).param = [P1_run3{1}];
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(1).pmod(1).poly = 1;
matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(1).pmod(2).name = 'U_solo';
%%

matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(1).pmod(2).param = [P2_run3{1}];
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(1).pmod(2).poly = 1;
matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(1).pmod(3).name = 'direction';
%%

matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(1).pmod(3).param = [di{3}];
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(1).pmod(3).poly = 1;
matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(1).pmod(4).name = 'direction_m';
%%

matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(1).pmod(4).param = [di_m{3}];
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(1).pmod(4).poly = 1;
matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(1).orth = 1;
matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(2).name = 'solo_mix';
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(2).onset = [onset_solo_mix{3}];
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(2).duration = 0;
matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(2).tmod = 0;
matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(2).pmod = struct('name', {}, 'param', {}, 'poly', {});
matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(2).orth = 1;

matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(3).name = 'not_conform';
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(3).onset = [onset_nc{3}];
%%
matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(3).duration = 0;
matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(3).tmod = 0;
matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(3).pmod = struct('name', {}, 'param', {}, 'poly', {});
matlabbatch{1}.spm.stats.fmri_spec.sess(3).cond(3).orth = 1;

matlabbatch{1}.spm.stats.fmri_spec.sess(3).multi = {''};
matlabbatch{1}.spm.stats.fmri_spec.sess(3).regress = struct('name', {}, 'val', {});
matlabbatch{1}.spm.stats.fmri_spec.sess(3).multi_reg = {FD_Scans{3}};
matlabbatch{1}.spm.stats.fmri_spec.sess(3).hpf = 128;
matlabbatch{1}.spm.stats.fmri_spec.fact = struct('name', {}, 'lgainels', {});
matlabbatch{1}.spm.stats.fmri_spec.bases.hrf.derivs = [0 0];
matlabbatch{1}.spm.stats.fmri_spec.volt = 1;
matlabbatch{1}.spm.stats.fmri_spec.global = 'Scaling';
matlabbatch{1}.spm.stats.fmri_spec.mthresh = 0.8;
matlabbatch{1}.spm.stats.fmri_spec.mask = {''};
matlabbatch{1}.spm.stats.fmri_spec.cvi = 'AR(1)';
matlabbatch{2}.spm.stats.fmri_est.spmmat(1) = cfg_dep('fMRI model specification: SPM.mat File', substruct('.','val', '{}',{1}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('.','spmmat'));
matlabbatch{2}.spm.stats.fmri_est.write_residuals = 0;
matlabbatch{2}.spm.stats.fmri_est.method.Classical = 1;
matlabbatch{3}.spm.stats.con.spmmat(1) = cfg_dep('Model estimation: SPM.mat File', substruct('.','val', '{}',{2}, '.','val', '{}',{1}, '.','val', '{}',{1}), substruct('.','spmmat'));
matlabbatch{3}.spm.stats.con.consess{1}.tcon.name = 'U_ocu';
matlabbatch{3}.spm.stats.con.consess{1}.tcon.weights = [0 1 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0];
matlabbatch{3}.spm.stats.con.consess{1}.tcon.sessrep = 'none';
matlabbatch{3}.spm.stats.con.consess{2}.tcon.name = 'U_solo';
matlabbatch{3}.spm.stats.con.consess{2}.tcon.weights = [0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0];
matlabbatch{3}.spm.stats.con.consess{2}.tcon.sessrep = 'none';
matlabbatch{3}.spm.stats.con.consess{3}.tcon.name = 'U_ocu-U_solo';
matlabbatch{3}.spm.stats.con.consess{3}.tcon.weights = [0 1 -1 0 0 0 0 0 0 0 0 0 0 0 1 -1 0 0 0 0 0 0 0 0 0 0 0 1 -1 0 0 0 0 0 0 0 0 0 0];
matlabbatch{3}.spm.stats.con.consess{3}.tcon.sessrep = 'none';
matlabbatch{3}.spm.stats.con.consess{4}.tcon.name = 'direction';
matlabbatch{3}.spm.stats.con.consess{4}.tcon.weights = [0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0];
matlabbatch{3}.spm.stats.con.consess{4}.tcon.sessrep = 'none';
matlabbatch{3}.spm.stats.con.consess{5}.tcon.name = 'direction_m';
matlabbatch{3}.spm.stats.con.consess{5}.tcon.weights = [0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0];
matlabbatch{3}.spm.stats.con.consess{5}.tcon.sessrep = 'none';
matlabbatch{3}.spm.stats.con.consess{6}.tcon.name = 'c-nc';
matlabbatch{3}.spm.stats.con.consess{6}.tcon.weights = [1 0 0 0 0 0 -1 0 0 0 0 0 0 1 0 0 0 0 0 -1 0 0 0 0 0 0 1 0 0 0 0 0 -1 0 0 0 0 0 0];
matlabbatch{3}.spm.stats.con.consess{6}.tcon.sessrep = 'none';
matlabbatch{3}.spm.stats.con.delete = 1;
spm_jobman('run',matlabbatch);