clear

cd ('K:\czdata\code')
load par_lambda.mat
par_lambda(11,:)=[];
lam_l_H=sortrows(par_lambda,2);
l_26=sortrows(lam_l_H(1:26,1),1);
h_25=sortrows(lam_l_H(27:51,1),1);
%%
funcdata_path_sl = 'K:\czdata\PPI\PPI\safe_Insula\low';
funcdata_path_rl = 'K:\czdata\PPI\PPI\risk_Insula\low';
cd (funcdata_path_sl);   
sub_list=dir ('S*');  
for i =1:size(sub_list,1) 
    subj(i,:) = sub_list(i).name; 
end
subj = cellstr(subj);
for Si = 1:length(subj)
    %%
        run_path_sl = fullfile(funcdata_path_sl,subj{Si});
        run_path_rl = fullfile(funcdata_path_rl,subj{Si});
        run_files1 = dir(fullfile(run_path_sl,'con_0001.nii'));
        run_files2 = dir(fullfile(run_path_rl,'con_0001.nii'));
        sess_scans1 = [];
        sess_scans1 = strcat(run_path_sl,'\',[run_files1.name],',1');  
        sess_scans2 = [];
        sess_scans2 = strcat(run_path_rl,'\',[run_files2.name],',1');        
       low_scan{Si}{1}=sess_scans1;
       low_scan{Si}{2}=sess_scans2;
       low_scan{Si}=low_scan{Si}';
end

%%
funcdata_path_sh = 'K:\czdata\PPI\PPI\safe_Insula\high';
funcdata_path_rh = 'K:\czdata\PPI\PPI\risk_Insula\high';
cd (funcdata_path_sh);     
sub_list=dir ('S*'); 
clear subj
for i =1:size(sub_list,1) 
    subj(i,:) = sub_list(i).name; 
end
subj = cellstr(subj);
for Si = 1:length(subj)
    %%
       run_path_sh = fullfile(funcdata_path_sh,subj{Si});
        run_path_rh = fullfile(funcdata_path_rh,subj{Si});
        run_files1 = dir(fullfile(run_path_sh,'con_0001.nii'));
        run_files2 = dir(fullfile(run_path_rh,'con_0001.nii'));
        sess_scans1 = [];
        sess_scans1 = strcat(run_path_sh,'\',[run_files1.name],',1');  
        sess_scans2 = [];
        sess_scans2 = strcat(run_path_rh,'\',[run_files2.name],',1');       
       high_scan{Si}{1}=sess_scans1;
       high_scan{Si}{2}=sess_scans2;
       high_scan{Si}=high_scan{Si}';
end
scans=[low_scan';high_scan'];


%%
 cd K:\czdata\code

    ano_job(scans)
