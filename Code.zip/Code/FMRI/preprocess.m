% List of open inputs
clc
clear


%%
funcdata_path = 'I:\pro429\SA_CON_fmri\Data_fmri\FunImg';
cd (funcdata_path);   
sub_list=dir ('S*');  
for i =1:size(sub_list,1) 
    subj(i,:) = sub_list(i).name; 
end
subj = cellstr(subj);
sess = { '2_ep2d_bold_task_run1' '3_ep2d_bold_task_run2' '4_ep2d_bold_task_run3'}; %write your session based on task fmri design

for Si = 1:length(subj)
    %%
    fun_scans = cell(1,length(sess));
    for Ti = 1:length(sess)   
        run_path = fullfile(funcdata_path,subj{Si},sess{Ti});
        run_files = dir(fullfile(run_path,'f*.nii'));
        sess_scans = [];
        for i = 1:length(run_files)
        sess_scans{i,1} = strcat(run_path,'\',[run_files(i).name],',1');
        end
        fun_scans{1,Ti} = sess_scans;
    end 

    scans(Si,:)=fun_scans(1,:);
    %% 
       T1_path=fullfile(funcdata_path,subj(Si,1),'5_t1_mprage_sag_iso_TI1000');
       T1_files = dir(fullfile(T1_path{1},'s*.nii'));
       T1_scans{Si}=strcat(T1_path,'\',[T1_files.name]);     
    %%
       path_raw='K:\czdata\FunRaw';
       for Ti = 1:length(sess)   
        run_path = fullfile(path_raw,subj{Si},sess{Ti});
        run_files = dir(fullfile(run_path,'*.IMA'));
        a=strcat(path_raw,'\',subj(Si,1),'\',[sess(Ti)],'\',[run_files(1).name]);
        info=dicominfo(a{1});
        slice_time_run{Ti}=info.Private_0019_1029;
      end
    S_t(Si,:)=slice_time_run(1,:);
end

  
  cd K:\czdata\code
%%
nrun=52;
for ru=1:3
ru=3 
for sub = 24%25:nrun
   % crun=list(sub,1);
   crun=sub;
    preprocess_job(scans{crun,ru},T1_scans{1,crun},S_t{crun,ru});
end
end


%%
%ɾ���м��ļ�


for Si = 1:length(subj)
    %%
    for Ti = 1:length(sess)   
        run_path = fullfile(funcdata_path,subj{Si},sess{Ti});
        cd(fullfile(funcdata_path,subj{Si},sess{Ti}))
        run_files = dir(fullfile(run_path,'raf*.nii'));
        for i = 1:length(run_files)
        delete([run_files(i).name]);
        end
    end
end
%%    ��FDֵ
  cd D:\anxiety\pro\mm\four_fmri_2.0\Data\fmri\FunImg\code
for Si = 2:length(subj)
    
    for Ti =1:length(sess)   
        run_path = fullfile(funcdata_path,subj{Si},sess{Ti});
        run_files = dir(fullfile(run_path,'rp*.txt'));
        F_scans = strcat(run_path,'\',[run_files.name]);
         mfd(Si,Ti) = wgr_mean_FD(F_scans);
         fd_scans{1,Ti} = F_scans;
    end
    FD_scans(Si,:)=fd_scans(1,:);
end 
