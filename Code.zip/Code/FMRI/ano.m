clear

cd ('K:\czdata\code')
load par_lambda.mat
par_lambda([2,11,39,48],:)=[];
lam_l_H=sortrows(par_lambda,2);
l_24=sortrows(lam_l_H(1:24),1);
h_24=sortrows(lam_l_H(25:48,1),1);
%%
funcdata_path = 'K:\czdata\first_level\sr_mix_\low';
cd (funcdata_path);   
sub_list=dir ('S*');  
for i =1:size(sub_list,1) 
    subj(i,:) = sub_list(i).name; 
end
subj = cellstr(subj);
for Si = 1:length(subj)
    %%
        run_path = fullfile(funcdata_path,subj{Si});
        run_files1 = dir(fullfile(run_path,'con_0006.nii'));
        run_files2 = dir(fullfile(run_path,'con_0007.nii'));
        sess_scans1 = [];
        sess_scans1 = strcat(run_path,'\',[run_files1.name],',1');  
        sess_scans2 = [];
        sess_scans2 = strcat(run_path,'\',[run_files2.name],',1');        
       low_scan{Si}{1}=sess_scans1;
       low_scan{Si}{2}=sess_scans2;
       low_scan{Si}=low_scan{Si}';
end
%%
funcdata_path = 'K:\czdata\first_level\sr_mix_\high';
cd (funcdata_path);   
sub_list=dir ('S*'); 
clear subj
for i =1:size(sub_list,1) 
    subj(i,:) = sub_list(i).name; 
end
subj = cellstr(subj);
for Si = 1:length(subj)
    %%
        run_path = fullfile(funcdata_path,subj{Si});
        run_files1 = dir(fullfile(run_path,'con_0006.nii'));
        run_files2 = dir(fullfile(run_path,'con_0007.nii'));
        sess_scans1 = [];
        sess_scans1 = strcat(run_path,'\',[run_files1.name],',1');  
        sess_scans2 = [];
        sess_scans2 = strcat(run_path,'\',[run_files2.name],',1');        
       high_scan{Si}{1}=sess_scans1;
       high_scan{Si}{2}=sess_scans2;
       high_scan{Si}=high_scan{Si}';
end
scans=[low_scan';high_scan'];


%%
 cd K:\czdata\group_level\sr_mix\anova

    ano_job(scans)
