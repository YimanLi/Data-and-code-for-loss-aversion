library(StanHeaders)
library(Rcpp)
library(ggplot2)
library(rstan)
library(hBayesDM)

setwd('D:\\lym_model')
datalist <- as.matrix(read.csv("Ra.txt", sep = "", header = TRUE))
d<-data.frame(datalist)

#insert data
data<-d

# Use the given data object
raw_data<-data.table::as.data.table(data)

# Save initial colnames of raw_data for later
colnames_raw_data<-colnames(raw_data)
colnames(raw_data)<-tolower(gsub("_","",colnames(raw_data),
                                 fixed = TRUE))


subjs<-NULL
n_subjs<-NULL
b_subjs<-NULL
b_max<-NULL
t_subjs<-NULL
t_max<-NULL

# To avoid NOTEs by R CMD check
.N<-NULL
subjid<-NULL


DT_trials<-raw_data[,.N,by = "subjid"]
subjs<-DT_trials$subjid
n_subj<-length(subjs)
t_subjs<-DT_trials$N
t_max<-max(t_subjs)

general_info<-list(subjs,n_subj,b_subjs,b_max,t_subjs,t_max)
names(general_info)<-c("subjs","n_subj","b_subjs","b_max","t_subjs","t_max")


# Use general_info of raw_data
subjs   <- general_info$subjs
n_subj  <- general_info$n_subj 
t_subjs <- general_info$t_subjs
t_max   <- general_info$t_max

# Initialize (model-specific) data arrays
condition     <- array( 0, c(n_subj, t_max))
p_gamble      <- array( 0, c(n_subj, t_max))
safe_Hpayoff  <- array( 0, c(n_subj, t_max))
safe_Lpayoff  <- array( 0, c(n_subj, t_max))
risky_Hpayoff <- array( 0, c(n_subj, t_max))
risky_Lpayoff <- array( 0, c(n_subj, t_max))
choice        <- array(-1, c(n_subj, t_max))


# Write from raw_data to the data arrays
for (i in 1:n_subj) {
  subj <- subjs[i]
  t <- t_subjs[i]
  DT_subj <- raw_data[raw_data$subjid == subj]
  
  condition[i, 1:t]     <- DT_subj$condition
  p_gamble[i, 1:t]      <- DT_subj$pgamble
  safe_Hpayoff[i, 1:t]  <- DT_subj$safehpayoff
  safe_Lpayoff[i, 1:t]  <- DT_subj$safelpayoff
  risky_Hpayoff[i, 1:t] <- DT_subj$riskyhpayoff
  risky_Lpayoff[i, 1:t] <- DT_subj$riskylpayoff
  choice[i, 1:t]        <- DT_subj$choice
}
  # Wrap into a list for Stan
  data_list <- list(
    N             = n_subj,
    T             = t_max,
    Tsubj         = t_subjs,
    condition     = condition,
    p_gamble      = p_gamble,
    safe_Hpayoff  = safe_Hpayoff,
    safe_Lpayoff  = safe_Lpayoff,
    risky_Hpayoff = risky_Hpayoff,
    risky_Lpayoff = risky_Lpayoff,
    choice        = choice
  )
  

  # The parameters of interest for Stan
  parameters      = list("rho" = c(0, 1, 2),"tau" = c(0, 1, Inf),
                         "ocu" = c(-Inf, 0, Inf),  "lambda" = c(0, 1, 5))

  pars <- character()
  pars <- c(pars, names(parameters))
  pars <- c(pars, paste0("mu_", names(parameters)), "sigma")
  pars <- c(pars, "log_lik")
  
  
  regressors      = NULL
  postpreds       = c("y_pred")
  modelRegressor = FALSE
  inc_postpred   = TRUE
  
  # Check if regressor available for this model
  if (modelRegressor && is.null(regressors)) {
    stop("** Model-based regressors are not available for this model. **\n")
  }
  
  # Check if postpred available for this model
  if (inc_postpred && is.null(postpreds)) {
    stop("** Posterior predictions are not yet available for this model. **\n")
  }
  
  if (modelRegressor) {
    pars <- c(pars, names(regressors))
  }
  if (inc_postpred) {
    pars <- c(pars, postpreds)
  }
  
  # Set number of cores for parallel computing
  rstan_options(auto_write = TRUE) 
  options(mc.cores = parallel::detectCores())
  
  setwd("D:\\anxiety\\model\\result\\OCU_rho_lambda")
  #stanmodel_arg <- stanmodels[[model]]
  stanmodel_arg <- rstan::stan_model("peer_ocu.stan")
  
  
  # Initial values for the parameters
  vb = FALSE
  gen_init <- NULL
  inits          = "vb"
  if (inits[1] == "vb") {
    if (vb) {
      cat("\n")
      cat("*****************************************\n")
      cat("** Use random values as initial values **\n")
      cat("*****************************************\n")
      gen_init <- "random"
      
    } else {
      cat("\n")
      cat("****************************************\n")
      cat("** Use VB estimates as initial values **\n")
      cat("****************************************\n")
      
      make_gen_init_from_vb <- function() {
        fit_vb <- rstan::vb(object = stanmodel_arg, data = data_list)
        m_vb <- colMeans(as.data.frame(fit_vb))
        
        function() {
          ret <- list(
            mu_pr = as.vector(m_vb[startsWith(names(m_vb), "mu_pr")]),
            sigma = as.vector(m_vb[startsWith(names(m_vb), "sigma")])
          )
          
          for (p in names(parameters)) {
            ret[[paste0(p, "_pr")]] <-
              as.vector(m_vb[startsWith(names(m_vb), paste0(p, "_pr"))])
          }
          
          return(ret)
        }
      }
      
      gen_init <- tryCatch(make_gen_init_from_vb(), error = function(e) {
        cat("\n")
        cat("******************************************\n")
        cat("** Failed to obtain VB estimates.       **\n")
        cat("** Use random values as initial values. **\n")
        cat("******************************************\n")
        
        return("random")
      })
    }
  } else if (inits[1] == "random") {
    cat("\n")
    cat("*****************************************\n")
    cat("** Use random values as initial values **\n")
    cat("*****************************************\n")
    gen_init <- "random"
  } else {
    if (inits[1] == "fixed") {
      # plausible values of each parameter
      inits <- unlist(lapply(parameters, "[", 2))
    } else if (length(inits) != length(parameters)) {
      stop("** Length of 'inits' must be ", length(parameters), " ",
           "(= the number of parameters of this model). ",
           "Please check again. **\n")
    }
    
      gen_init <- function() {
        primes <- numeric(length(parameters))
        for (i in 1:length(parameters)) {
          lb <- parameters[[i]][1]   # lower bound
          ub <- parameters[[i]][3]   # upper bound
          if (is.infinite(lb)) {
            primes[i] <- inits[i]                             # (-Inf, Inf)
          } else if (is.infinite(ub)) {
            primes[i] <- log(inits[i] - lb)                   # (  lb, Inf)
          } else {
            primes[i] <- qnorm((inits[i] - lb) / (ub - lb))   # (  lb,  ub)
          }
        }
        group_level             <- list(mu_pr = primes,
                                        sigma = rep(1.0, length(primes)))
        individual_level        <- lapply(primes, function(x) rep(x, n_subj))
        names(individual_level) <- paste0(names(parameters), "_pr")
        return(c(group_level, individual_level))
      }
    }
  


  
  # Fit the Stan model
  #if (vb) {
    #fit <- rstan::vb(object = stanmodel_arg,
                     #data   = data_list,
                     #pars   = pars,
                     #init   = gen_init)
  #} else {
    fit <- rstan::sampling(object = stanmodel_arg,
                           data    = data_list,
                           pars    = pars,
                           init    = gen_init,
                           cores   = 2,
                           chains  = 4,
                           iter    = 4000,
                           warmup  = 1000,
                           thin    = 1,
                           control = list(adapt_delta   = 0.95,
                                          stepsize      = 1,
                                          max_treedepth = 10))
  #}
  
  # Extract from the Stan fit object
  parVals <- rstan::extract(fit, permuted = TRUE)
  
  # Trial-level posterior predictive simulations
  if (inc_postpred) {
    for (pp in postpreds) {
      parVals[[pp]][parVals[[pp]] == -1] <- NA
    }
  }
  
  indPars = "mean"
  
  # Define measurement of individual parameters
  measure_indPars <- switch(indPars, mean = mean, median = median, mode = estimate_mode)
  
  # Define which individual parameters to measure
  which_indPars <- names(parameters)
  
  # Measure all individual parameters (per subject)
  allIndPars <- as.data.frame(array(NA, c(n_subj, length(which_indPars))))
  
    for (i in 1:n_subj) {
      allIndPars[i, ] <- mapply(function(x) measure_indPars(parVals[[x]][, i]), which_indPars)
    }

  allIndPars <- cbind(subjs, allIndPars)
  colnames(allIndPars) <- c("subjID", which_indPars)
  
  # Model regressors (for model-based neuroimaging, etc.)
  if (modelRegressor) {
    model_regressor <- list()
    for (r in names(regressors)) {
      model_regressor[[r]] <- apply(parVals[[r]], c(1:regressors[[r]]) + 1, measure_indPars)
    }
  }
  
  
  # Give back initial colnames and revert data.table to data.frame
  colnames(raw_data) <- colnames_raw_data
  raw_data <- as.data.frame(raw_data)
  
  # Wrap up data into a list
  modelData                   <- list()
  modelData$allIndPars        <- allIndPars
  modelData$parVals           <- parVals
  modelData$fit               <- fit
  modelData$rawdata           <- raw_data
  if (modelRegressor) {
    modelData$modelRegressor  <- model_regressor
  }
      
  #caculate LOOIC  
  LOOIC<-extract_ic(modelData, ic = "looic", ncore = 2)
