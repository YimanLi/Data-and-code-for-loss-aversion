% clear
% clc
% %%
% path='D:\loss_aversion\pro\mm\four_fmri_2.0\Data\behavior';
% cd(path) 
% suffix='.txt';
% load('subjects.mat');
% load parameter_rho.mat   % subID rho ocu lambda
% subjects(1:52,1)=[1:52];
% %prefix=文件前缀
% prefix='SDT_one_';
% for i=1:length(subjects)
% sss=num2str(subjects(i,1));
% run_{1,i}=importdata(fullfile(path,[prefix,sss,suffix]));   %run*sub
% end
% prefix='SDT_two_';
% for i=1:length(subjects)
% sss=num2str(subjects(i,1));
% run_{2,i}=importdata(fullfile(path,[prefix,sss,suffix]));
% end
% prefix='SDT_three_';
% for i=1:length(subjects)
% sss=num2str(subjects(i,1));
% run_{3,i}=importdata(fullfile(path,[prefix,sss,suffix]));
% end
% 
% cd D:\loss_aversion\pro\mm\four_fmri_2.0\Data\behavior
% 
% for h=1:52
%     load(['sub_','one_',num2str(h),'.mat']);% 3 (1)SSSR,(2)SSSS;4 (1)RRRS,(2)RRRR
%     SP{h}(intersect(find(data(:,4)==3),find(data(:,12)==2)),1)=0;
%     SP{h}(intersect(find(data(:,4)==3),find(data(:,12)==1)),1)=1;
%     SP{h}(data(:,4)==2,1)=2;
%     SP{h}(intersect(find(data(:,4)==4),find(data(:,12)==1)),1)=3;
%     SP{h}(intersect(find(data(:,4)==4),find(data(:,12)==2)),1)=4;
%     SP{h}(data(:,4)==1,1)=5;
% end
clear
cd  /Users/yiman/Desktop/Study_loss/20230216
load data_or.mat

for sub=1:length(subjects)
for r=1:3
social_context{sub,r}(:,1)=run_{r,sub}.data(:,6);  %social con   1solo;2Mix;3Ssfe;4Risk  // 0: solo, 1: ss, 2: mix, 3: rr
social_context{sub,r}(:,2)=run_{r,sub}.data(:,13);  %dec  risk1 safe0
social_context{sub,r}(:,3)=run_{r,sub}.data(:,8);  %gain
social_context{sub,r}(:,4)=0-run_{r,sub}.data(:,9);   %loss
social_context{sub,r}(:,7)=run_{r,sub}.data(:,4);  %gain order
social_context{sub,r}(:,8)=run_{r,sub}.data(:,5);   %loss order
social_context{sub,r}(:,5)=run_{r,sub}.data(:,14)-run_{r,sub}.data(1,18);  %dec onset
social_context{sub,r}(:,6)=run_{r,sub}.data(:,15)-run_{r,sub}.data(1,18);  %outcome  onset
social_context{sub,r}(:,9)=ones(108,1)*r;
social_context{sub,r}(:,10)=run_{r,sub}.data(:,12);   %RT
social_context{sub,r}(:,15)=run_{r,sub}.data(:,3); %trail number
end
social_context{sub,4}=[social_context{sub,1};social_context{sub,2};social_context{sub,3}];
social_context{sub,4}(:,11)=1:324;
social_context{sub,4}(:,12)=ones(324,1)*5;

%predict p（percentage choose safe）
y_pre{sub}=pre(sub,:);
y_pre{sub}(:,y_pre{sub}==5)=[];
y_pre{sub}=y_pre{sub}';
N=ismissing(social_context{sub,4}(:,2));%dec
l=find(N==1);
dire{sub}=y_pre{sub}';
for i=1:length(l)% NaN
    dire{sub}=[dire{sub}(1:l(i,1)-1) 6 dire{sub}(l(i,1):end)]; 
end
social_context{sub,4}(:,13)=dire{sub}';
for t=1:length(social_context{sub,4})
  Y{sub}(social_context{sub,4}(t,15),1)=social_context{sub,4}(t,13);
  Y{sub}(social_context{sub,4}(t,15),2)=social_context{sub,4}(t,2);
end
%social_context{sub,4}(Y{sub}(:,1)<0.5,2)=0;
%social_context{sub,4}(Y{sub}(:,1)>=0.5,2)=1;

social_context{sub,4}(:,14)=SP{sub};  %social influence: 0~5 0/4-4/0 choose risk
social_context{sub,4}(social_context{sub,4}(:,13)==6,:)=[]; % delete NaN
social_context{sub,4}(intersect(find(social_context{sub,4}(:,1)==3),find(social_context{sub,4}(:,2)==0)),15)=1;%conform safe 1
social_context{sub,4}(intersect(find(social_context{sub,4}(:,1)==4),find(social_context{sub,4}(:,2)==1)),15)=1;%conform risk 1
social_context{sub,4}(intersect(find(social_context{sub,4}(:,1)==3),find(social_context{sub,4}(:,2)==1)),15)=-1;%not conform safe -1
social_context{sub,4}(intersect(find(social_context{sub,4}(:,1)==4),find(social_context{sub,4}(:,2)==0)),15)=-1;%not conform risk -1
con_safe(sub,1)=length(find(social_context{sub,4}(social_context{sub,4}(:,1)==3,2)==0))/length(find(social_context{sub,4}(:,1)==3));
con_risk(sub,1)=length(find(social_context{sub,4}(social_context{sub,4}(:,1)==4,2)==1))/length(find(social_context{sub,4}(:,1)==4));
%continuous social influence
con_cont(sub,1)=length(find(social_context{sub,4}(social_context{sub,4}(:,14)==0,2)==0))/length(find(social_context{sub,4}(:,14)==0));%0 choose risk/4 choose safe
con_cont(sub,2)=length(find(social_context{sub,4}(social_context{sub,4}(:,14)==1,2)==0))/length(find(social_context{sub,4}(:,14)==1));
con_cont(sub,3)=length(find(social_context{sub,4}(social_context{sub,4}(:,14)==2,2)==0))/length(find(social_context{sub,4}(:,14)==2));
con_cont(sub,4)=length(find(social_context{sub,4}(social_context{sub,4}(:,14)==3,2)==1))/length(find(social_context{sub,4}(:,14)==3));
con_cont(sub,5)=length(find(social_context{sub,4}(social_context{sub,4}(:,14)==4,2)==1))/length(find(social_context{sub,4}(:,14)==4));
%%
P_safe(sub,1)=length(find(social_context{sub,4}(social_context{sub,4}(:,14)==0,2)==0))/length(find(social_context{sub,4}(:,14)==0));%0 choose risk/4 choose safe
P_safe(sub,2)=length(find(social_context{sub,4}(social_context{sub,4}(:,14)==1,2)==0))/length(find(social_context{sub,4}(:,14)==1));
P_safe(sub,3)=length(find(social_context{sub,4}(social_context{sub,4}(:,14)==2,2)==0))/length(find(social_context{sub,4}(:,14)==2));
P_safe(sub,4)=length(find(social_context{sub,4}(social_context{sub,4}(:,14)==3,2)==0))/length(find(social_context{sub,4}(:,14)==3));
P_safe(sub,5)=length(find(social_context{sub,4}(social_context{sub,4}(:,14)==4,2)==0))/length(find(social_context{sub,4}(:,14)==4));
P_safe(sub,6)=length(find(social_context{sub,4}(social_context{sub,4}(:,14)==5,2)==0))/length(find(social_context{sub,4}(:,14)==5));
P_safe(sub,7)=length(find(social_context{sub,4}(social_context{sub,4}(:,1)==3,2)==0))/length(find(social_context{sub,4}(:,1)==3));%safe influence
P_safe(sub,8)=length(find(social_context{sub,4}(social_context{sub,4}(:,1)==4,2)==0))/length(find(social_context{sub,4}(:,1)==4));%risk influence


end  
%% P（safe option）-solo
P_safe_solo=P_safe-P_safe(:,6);

%%   real Y  Pre Y
 
Y_m=Y{1};
 for i=1:51
    Y_m=[Y_m;Y{i+1}];
 end
 
Y_m(Y_m(:,1)==6,:)=[]; %delete trails

[r p]=corr(Y_m(:,1),Y_m(:,2))

%mean
for i=1:52
  m_Y{1}(:,i)=(Y{i}(:,1));%pre
  m_Y{2}(:,i)=(Y{i}(:,2));%real
end

for i=1:324
  m_Y{3}(i,2)=mean(m_Y{1}(i,m_Y{1}(i,:)~=6));
  m_Y{3}(i,3)=mean(m_Y{2}(i,m_Y{1}(i,:)~=6));
end

m_Y{3}(:,1)=[1:324]';

[r p]=corr(m_Y{3}(:,1),m_Y{3}(:,2))
plot(m_Y{3}(:,1))
%%

%% Linear Mix Model  choice

par(:,3)=[];
for i=1:52
    M_model{i}(:,1)=ones(length(social_context{i,4}),1)*i; %num
    M_model{i}(:,2)=social_context{i,4}(:,2);%decision
    M_model{i}(:,3)=social_context{i,4}(:,14);%social influence 0~4 0/4-4/0 choose risk
    M_model{i}(:,4)=social_context{i,4}(:,1);%social con   1solo;2Mix;3Ssfe;4Risk
    M_model{i}(:,5:6)=repmat(par(i,[2:3]),length(social_context{i,4}),1); %rho lambda
 end
M_m=M_model{1};
 for i=1:51
    M_m=[M_m;M_model{i+1}];
 end
   
  M_m(find(sum(M_m(:,3)==[5],2)==1),:)=[];
  
%conformity in each trail
M_m_con=M_m;
M_m_con(intersect(find(M_m(:,4)==3),find(M_m(:,2)==0)),2)=1;
M_m_con(intersect(find(M_m(:,4)==3),find(M_m(:,2)==1)),2)=0;
M_m_con(intersect(find(M_m(:,4)==4),find(M_m(:,2)==1)),2)=1;
M_m_con(intersect(find(M_m(:,4)==4),find(M_m(:,2)==0)),2)=0;


%conformity  in condition
for i=1:52
    M_model_con{i}(:,1)=ones(5,1)*i; %num
    M_model_con{i}(:,2)=con_cont(i,:)';     
    M_model_con{i}(:,3)=[0:4]'; %social influence
    M_model_con{i}(:,4:5)=repmat(par(i,[2:3]),5,1);
end
 M_con=M_model_con{1};
  for i=1:51
    M_con=[M_con;M_model_con{i+1}];
  end
  
  
  M_con_safe=M_con;
  M_con_safe(find(sum(M_con(:,3)==[3 4],2)==1),:)=[];

  M_con(M_con(:,3)==2,2)=1-M_con(M_con(:,3)==2,2);

  M_con_risk=M_con;
  M_con_risk(find(sum(M_con(:,3)==[0 1],2)==1),:)=[];

%conformity  in condition safe/risk
for i=1:52
    M_model_con_sr{i}(:,1)=ones(2,1)*i; %num
    M_model_con_sr{i}(:,2)=[con_safe(i,1),con_risk(i,1)];     
    M_model_con_sr{i}(:,3)=[1:2]'; %social influence  1 safe 2risk
    M_model_con_sr{i}(:,4:5)=repmat(par(i,[2:3]),2,1);
end
 M_con_sr=M_model_con_sr{1};
  for i=1:51
    M_con_sr=[M_con_sr;M_model_con_sr{i+1}];
  end
  


 % safe option in condition

for i=1:52
    M_model_ps{i}(:,1)=ones(5,1)*i; %num
    M_model_ps{i}(:,2)=P_safe_solo(i,[1:5])';     
    M_model_ps{i}(:,3)=[0:4]'; %social influence
    M_model_ps{i}(:,4:5)=repmat(par(i,[2:3]),5,1);
end
 M_ps=M_model_ps{1};
  for i=1:51
    M_ps=[M_ps;M_model_ps{i+1}];
  end

for i=1:52
    M_model_ps_sr{i}(:,1)=ones(2,1)*i; %num
    M_model_ps_sr{i}(:,2)=P_safe_solo(i,[7:8])';     
    M_model_ps_sr{i}(:,3)=[1:2]'; %social influence
    M_model_ps_sr{i}(:,4:5)=repmat(par(i,[2:3]),2,1);
end
 M_ps_sr=M_model_ps_sr{1};
  for i=1:51
    M_ps_sr=[M_ps_sr;M_model_ps_sr{i+1}];
  end


%% predict data     Linear Mix Model  choice
for i=1:52
    Y{i}(Y{i}(:,1)==6,:)=[];
end

for i=1:52
    M_model{i}(:,1)=ones(length(social_context{i,4}),1)*i; %num
    M_model{i}(:,2)=Y{i}(:,1);%decision
    M_model{i}(:,3)=social_context{i,4}(:,14);%social influence 0~4 0/4-4/0 choose risk
    M_model{i}(:,4)=social_context{i,4}(:,1);%social con   1solo;2Mix;3Ssfe;4Risk
    M_model{i}(:,5:6)=repmat(par(i,[2:3]),length(social_context{i,4}),1); %rho lambda
 end
M_m=M_model{1};
 for i=1:51
    M_m=[M_m;M_model{i+1}];
 end
   
  M_m(find(sum(M_m(:,3)==[5],2)==1),:)=[];
  
%conformity in each trail
M_m_con=M_m;
M_m_con(intersect(find(M_m(:,4)==3),find(M_m(:,2)==0)),2)=1;
M_m_con(intersect(find(M_m(:,4)==3),find(M_m(:,2)==1)),2)=0;
M_m_con(intersect(find(M_m(:,4)==4),find(M_m(:,2)==1)),2)=1;
M_m_con(intersect(find(M_m(:,4)==4),find(M_m(:,2)==0)),2)=0;

for sub=1:52
P_safe(sub,1)=mean(Y{sub}(social_context{sub,4}(:,14)==0,1));%0 choose risk/4 choose safe
P_safe(sub,2)=mean(Y{sub}(social_context{sub,4}(:,14)==1,1));
P_safe(sub,3)=mean(Y{sub}(social_context{sub,4}(:,14)==2,1));
P_safe(sub,4)=mean(Y{sub}(social_context{sub,4}(:,14)==3,1));
P_safe(sub,5)=mean(Y{sub}(social_context{sub,4}(:,14)==4,1));
P_safe(sub,6)=mean(Y{sub}(social_context{sub,4}(:,14)==5,1));
P_safe(sub,7)=mean(Y{sub}(social_context{sub,4}(:,1)==3,1));%safe influence
P_safe(sub,8)=mean(Y{sub}(social_context{sub,4}(:,1)==4,1));
end

%%  onset


%%
for sub=1:length(subjects)

%%
% %Onset
for r=1:3 %run
 %condition (social context)
a{sub,r}=ismissing(social_context{sub,r}(:,2));
social_context{sub,r}(find(a{sub,r}(:,1)==1),:)=[]; %删掉缺失trail
social_context{sub,r}(find(social_context{sub,r}(:,10)==-6),:)=[];%%删掉safe(1-6=-5)和risk(0-6=-6)条件相对应的缺失trail（缺失trail在solo）
social_context{sub,r}(find(social_context{sub,r}(:,10)==-5),:)=[];

%info trial
l_ss=intersect(find(social_context{sub,r}(:,1)==3),find(social_context{sub,r}(:,2)==0));%找到info trail的序号
l_sr=intersect(find(social_context{sub,r}(:,1)==3),find(social_context{sub,r}(:,2)==1));
l_rr=intersect(find(social_context{sub,r}(:,1)==4),find(social_context{sub,r}(:,2)==1));
l_rs=intersect(find(social_context{sub,r}(:,1)==4),find(social_context{sub,r}(:,2)==0));
condition_info_c{sub}{r,1}=social_context{sub,r}([l_ss;l_rr],5); 
condition_info_nc{sub}{r,1}=social_context{sub,r}([l_sr;l_rs],5); 
condition_solo_mix{sub}{r,1}=social_context{sub,r}([find(social_context{sub,r}(:,1)==1);find(social_context{sub,r}(:,1)==2)],5); 
condition_mix{sub}{r,1}=social_context{sub,r}(find(social_context{sub,r}(:,1)==2),5); 
condition_solo{sub}{r,1}=social_context{sub,r}(find(social_context{sub,r}(:,1)==1),5); 
for con=1:4% subID rho ocu lambda
    p3{sub}{r,con}=social_context{sub,r}(find(social_context{sub,r}(:,1)==con),3);%gain
    p4{sub}{r,con}=social_context{sub,r}(find(social_context{sub,r}(:,1)==con),4);%loss
    U_safe=0;    %Utility of safe choice
    U_risky{sub}{r,con}=0.5*p3{sub}{r,con}.^par_ocu_safe(sub,2)-0.5*par_ocu_safe(sub,1)*abs(p4{sub}{r,con}).^par_ocu_safe(sub,2);%Utility of risk choice
    if con==3  % safe condition 
    U_ocu_{sub}{r,con}=U_safe+par_ocu_safe(sub,3)- U_risky{sub}{r,con};
    elseif con==4 % risky condition 
    U_ocu_{sub}{r,con}=U_safe - U_risky{sub}{r,con};  
    else
    U_ocu_{sub}{r,con}=U_safe - U_risky{sub}{r,con}; 
    end
  U_solo_{sub}{r,con}=U_safe - U_risky{sub}{r,con};   
end 
%conform U_ocu Usolo 
U_ocu_a{sub}{r}=[U_ocu_{sub}{r,1};U_ocu_{sub}{r,2};U_ocu_{sub}{r,3};U_ocu_{sub}{r,4}];
U_solo_a{sub}{r}=[U_solo_{sub}{r,1};U_solo_{sub}{r,2};U_solo_{sub}{r,3};U_solo_{sub}{r,4}];
U_ocu{sub}{r}=U_ocu_a{sub}{r}([l_ss;l_rr],:);
U_solo{sub}{r}=U_solo_a{sub}{r}([l_ss;l_rr],:);
U_ocu{sub}{r}=zscore(U_ocu{sub}{r});
U_solo{sub}{r}=zscore(U_solo{sub}{r});

%direction
%direction{sub}{r}=[social_context{sub,r}(l_ss,10);social_context{sub,r}(l_rr,10)];

% direction{sub}{r}(find(direction{sub}{r}>0),1)=1;%
% direction{sub}{r}(find(direction{sub}{r}==0),1)=0;
% direction{sub}{r}(find(direction{sub}{r}<0),1)=-1;
direction_m{sub}{r}=abs([social_context{sub,r}(l_ss,10);social_context{sub,r}(l_rr,10)]);
direction4{sub}{r}=[-1*ones(length(l_ss),1);ones(length(l_rr),1)];
direction3{sub}{r}=[ones(length(l_ss),1);-1*ones(length(l_rr),1)];
end
end

