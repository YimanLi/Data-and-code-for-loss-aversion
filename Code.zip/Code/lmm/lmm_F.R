library(readxl)
library(lme4)
library(lmerTest)
library(tidyverse)
library(sjPlot)
# choice  sp
data_m <- read_excel('/Users/yiman/Desktop/Study_loss/20230216/llm/F_M_m.xlsx',sheet = 1)
C_m<-glmer(choice~rho+lambda+social_pressure+lambda*social_pressure+rho*social_pressure+(social_pressure|subjects),family= binomial(link='logit'),data=data_m)
#C_m<-lmer(choice~rho+lambda+social_pressure+lambda*social_pressure+rho*social_pressure+(social_pressure|subjects),data=data_m)

print(anova(C_m))
summary(C_m)

plot_model(C_m, type='emm', terms=c("lambda[all]","social_pressure"),alpha=0.15)+geom_hline(yintercept = 0.5,linetype="dashed",color="black",size=1)
plot_model(C_m, type='emm', terms=c("social_pressure[all]","lambda"),alpha=0.15)+geom_hline(yintercept = 0.5,linetype="dashed",color="black",size=1)

plot_model(C_m, type='emm', terms=c("rho[all]","social_pressure"),alpha=0.15)+geom_hline(yintercept = 0.5,linetype="dashed",color="black",size=1)
plot_model(C_m, type='emm', terms=c("social_pressure[all]","rho"),alpha=0.15)+geom_hline(yintercept = 0.5,linetype="dashed",color="black",size=1)

#C_m<-lmer(choice~rho+lambda+condition+lambda*social_in+rho*condition+(1|subjects),data=data_m)
#print(anova(C_m))

# conformity  trail  sp
data_m_con_t <- read_excel('/Users/yiman/Desktop/Study_loss/20230216/llm/F_M_m_con.xlsx',sheet = 1)
C_m_con_t<-glmer(conformity~rho+lambda+social_pressure+lambda*social_pressure+rho*social_pressure+(social_pressure|subjects),family= binomial(link='logit'),data=data_m_con_t)
#C_m_con_t<-lmer(conformity~rho+lambda+social_pressure+lambda*social_pressure+rho*social_pressure+(social_pressure|subjects),data=data_m_con_t)

print(anova(C_m_con_t))
summary(C_m_con_t)

plot_model(C_m_con_t, type='emm', terms=c("lambda[all]","social_pressure"),alpha=0.15)+geom_hline(yintercept = 0.5,linetype="dashed",color="black",size=1)
plot_model(C_m_con_t, type='emm', terms=c("social_pressure[all]","lambda"),alpha=0.15)+geom_hline(yintercept = 0.5,linetype="dashed",color="black",size=1)

# conformity  sp
#data_m_con <- read_excel('/Users/yiman/Desktop/Study_loss/20230216/llm/F_M_con.xlsx',sheet = 1)
#C_m_con<-lmer(conformity~rho+lambda+social_in+lambda*social_in+rho*social_in+(1|subjects),data=data_m_con)
#print(anova(C_m_con))

# safe option sr
data_ps_sr <- read_excel('/Users/yiman/Desktop/Study_loss/20230216/llm/Info_solo_sr.xlsx',sheet = 1)
C_ps_sr<-lmer(Info_solo~rho+lambda+sr+lambda*sr+(1|subjects),data=data_ps_sr)
print(anova(C_ps_sr))

# conformity  sr
data_m_con_sr <- read_excel('/Users/yiman/Desktop/Study_loss/20230216/llm/F_M_con_sr.xlsx',sheet = 1)
C_m_con_sr<-lmer(conformity~rho+lambda+social_in+lambda*social_in+(1|subjects),data=data_m_con_sr)
print(anova(C_m_con_sr))

# conformity  safe
data_m_con_safe <- read_excel('/Users/yiman/Desktop/Study_loss/20230216/llm/F_M_con_safe.xlsx',sheet = 1)
C_m_con_safe<-lmer(conformity~rho+lambda+social_in+lambda*social_in+(1|subjects),data=data_m_con_safe)
print(anova(C_m_con_safe))


# conformity  risk
data_m_con_risk <- read_excel('/Users/yiman/Desktop/Study_loss/20230216/llm/F_M_con_risk.xlsx',sheet = 1)
C_m_con_risk<-lmer(conformity~rho+lambda+social_in+lambda*social_in+(1|subjects),data=data_m_con_risk)
print(anova(C_m_con_risk))

# safe option sp
data_ps_sp <- read_excel('/Users/yiman/Desktop/Study_loss/20230216/llm/Info_solo_sp.xlsx',sheet = 1)
C_ps_sp<-lmer(Info_solo~rho+lambda+sp+lambda*sp+rho*sp+(1|subjects),data=data_ps_sp)
print(anova(C_ps_sp))



