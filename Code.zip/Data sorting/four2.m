%%
path='D:\loss_aversion\pro\mm\four_fmri_2.0\Data\behavior';
suffix='.txt';
%Ҫ���Ƶı��Ա�����д��subjects.mat�ļ��ڣ������뵱ǰĿ¼��
load('subjects.mat');
subjects=[1:52]';
%prefix=�ļ�ǰ׺
prefix='SDT_one_';
for i=1:length(subjects);
sss=num2str(subjects(i,1));
run_{1,i}=importdata(fullfile(path,[prefix,sss,suffix]));   %run*sub
end
prefix='SDT_two_';
for i=1:length(subjects);
sss=num2str(subjects(i,1));
run_{2,i}=importdata(fullfile(path,[prefix,sss,suffix]));
end
prefix='SDT_three_';
for i=1:length(subjects);
sss=num2str(subjects(i,1));
run_{3,i}=importdata(fullfile(path,[prefix,sss,suffix]));
end
%%

for sub=1:length(subjects)
for r=1:3
social_context{sub,r}(:,1)=run_{r,sub}.data(:,6);  %social con
social_context{sub,r}(:,2)=run_{r,sub}.data(:,13);  %dec
social_context{sub,r}(:,3)=run_{r,sub}.data(:,8);  %gain
social_context{sub,r}(:,4)=run_{r,sub}.data(:,9);   %loss
social_context{sub,r}(:,7)=run_{r,sub}.data(:,4);  %gain order
social_context{sub,r}(:,8)=run_{r,sub}.data(:,5);   %loss order
end
social_context{sub,4}=[social_context{sub,1};social_context{sub,2};social_context{sub,3}];
a=ismissing(social_context{sub,4}(:,2));
social_context{sub,4}(find(a==1),:)=[];
social_context{sub,4}(:,5)=social_context{sub,4}(:,3)*0.5-social_context{sub,4}(:,4)*0.5;%EV
social_context{sub,4}(:,6)=(social_context{sub,4}(:,3)*0.5+social_context{sub,4}(:,4)*0.5).^2;%Va
% for i=1:3
for i=1:4
dec{sub,i}=social_context{sub,4}(find(social_context{sub,4}(:,1)==i),:);
dec_s(sub,i)=1-sum(dec{sub,i}(:,2),1)/length(dec{sub,i}); %%type:1solo;2RRSS;3SSSS SSSR;4RRRR RRRS    Percentage safe choices 
end
mix(1,sub)=dec_s(sub,2)-dec_s(sub,1);   %Mix-solo
ss(1,sub)=dec_s(sub,3)-dec_s(sub,1);   %S-solo
rr(1,sub)=dec_s(sub,4)-dec_s(sub,1);  %R-solo
end

ps(1,:)=ss(1,:)
ps(2,:)=mix(1,:);
ps(3,:)=rr(1,:);
b=bar(ps)

%mean
m_s=mean(ss);
m_r=mean(rr);
m_mix=mean(mix)
d=[m_s;m_mix;m_r];
b=bar(d);
set(gca,'XTICKLabel',{'Safe','Mix','Risk'})
save social_contex.mat 

sub=1
%sub_123
d=[ss(1,sub);mix(1,sub);rr(1,sub)];
b=bar(d);
set(gca,'XTICKLabel',{'Safe','Mix','Risk'})


%%
%����dec�ֲ�
for sub=1:length(subjects)
for r=1:3
social_context{sub,r}(:,1)=run_{r,sub}.data(:,6);  %social con
social_context{sub,r}(:,2)=run_{r,sub}.data(:,13);  %dec
social_context{sub,r}(:,3)=run_{r,sub}.data(:,8);  %gain
social_context{sub,r}(:,4)=run_{r,sub}.data(:,9);   %loss
social_context{sub,r}(:,7)=run_{r,sub}.data(:,4);  %gain order
social_context{sub,r}(:,8)=run_{r,sub}.data(:,5);   %loss order
end
social_context{sub,4}=[social_context{sub,1};social_context{sub,2};social_context{sub,3}];

social_context{sub,4}(:,5)=social_context{sub,4}(:,3)*0.5-social_context{sub,4}(:,4)*0.5;%EV
social_context{sub,4}(:,6)=(social_context{sub,4}(:,3)*0.5+social_context{sub,4}(:,4)*0.5).^2;%Va
%for i=1:3
for i=1:4
dec{sub,i}=social_context{sub,4}(find(social_context{sub,4}(:,1)==i),:);
dec_s(sub,i)=1-sum(dec{sub,i}(:,2),1)/length(dec{sub,i}); %1solo;2RR;3SS;4mix    Percentage safe choices 
end
end

for sub=1:length(subjects)
for r=1:4    
%for r=1:3
for i=1:81
%for i=1:121
m{sub,r}(dec{sub,r}(i,7),dec{sub,r}(i,8))=dec{sub,r}(i,2);
end
end
    m_cha{sub,1}=m{sub,2}-m{sub,1}% Mix-solo
    m_cha{sub,2}=m{sub,4}-m{sub,1}% R-solo
    m_cha{sub,3}=m{sub,3}-m{sub,1}% S-solo
end




%for i=1:121
for i=1:81
EV_m(dec{1}(i,7),dec{1}(i,8))=dec{1}(i,5);
Var_m(dec{1}(i,7),dec{1}(i,8))=dec{1}(i,6);
gain(dec{1}(i,7),dec{1}(i,8))=dec{1}(i,3);
loss(dec{1}(i,7),dec{1}(i,8))=dec{1}(i,4);
end

heatmap(m{1,2}')
set(gca,'XTICKLabel',{'Safe','Risk'})
%%

%%
%ֻ������run

r=3
for sub=1:length(subjects)
a=ismissing(social_context{sub,r}(:,2));
social_context{sub,r}(find(a==1),:)=[];
for i=1:3
dec_run_1{sub,i}=social_context{sub,r}(find(social_context{sub,r}(:,1)==i),:);
dec_s_run_1(sub,i)=1-sum(dec_run_1{sub,i}(:,2),1)/length(dec_run_1{sub,i}); %1solo;2RR;3SS    Percentage safe choices 
end
rr_1(1,sub)=dec_s_run_1(sub,2)-dec_s_run_1(sub,1);   %RR-solo
ss_1(1,sub)=dec_s_run_1(sub,3)-dec_s_run_1(sub,1);   %SS-solo
end
m_s_3=mean(ss_1);
m_r_3=mean(rr_1);
d=[m_s_3;m_r_3];
b=bar(d);
set(gca,'XTICKLabel',{'Safe','Risk'})


%%
%gain or loss
dec_gl{1}=social_context{4}(find(social_context{4}(:,3)>social_context{4}(:,4)),:);
dec_gl{2}=social_context{4}(find(social_context{4}(:,3)<social_context{4}(:,4)),:);
dec_gl{3}=social_context{4}(find(social_context{4}(:,3)==social_context{4}(:,4)),:);
for i=1:3;
dec_p(1,i)=1-sum(dec_gl{i}(:,2))/length(dec_gl{i});  % g l s
end   
