clear
clc
%%
path='D:\loss_aversion\pro\mm\four_fmri_2.0\Data\behavior';
cd(path) 
suffix='.txt';
%Ҫ���Ƶı��Ա�����д��subjects.mat�ļ��ڣ������뵱ǰĿ¼��
load('subjects.mat');
load parameter_rho.mat   % subID rho ocu lambda
subjects(1:52,1)=[1:52];
%prefix=�ļ�ǰ׺
prefix='SDT_one_';
for i=1:length(subjects)
sss=num2str(subjects(i,1));
run_{1,i}=importdata(fullfile(path,[prefix,sss,suffix]));   %run*sub
end
prefix='SDT_two_';
for i=1:length(subjects)
sss=num2str(subjects(i,1));
run_{2,i}=importdata(fullfile(path,[prefix,sss,suffix]));
end
prefix='SDT_three_';
for i=1:length(subjects)
sss=num2str(subjects(i,1));
run_{3,i}=importdata(fullfile(path,[prefix,sss,suffix]));
end
%%

for sub=1:length(subjects)
for r=1:3
social_context{sub,r}(:,1)=run_{r,sub}.data(:,6);  %social con   1solo;2Mix;3Ssfe;4Risk  // 0: solo, 1: ss, 2: mix, 3: rr
social_context{sub,r}(:,2)=run_{r,sub}.data(:,13);  %dec
social_context{sub,r}(:,3)=run_{r,sub}.data(:,8);  %gain
social_context{sub,r}(:,4)=0-run_{r,sub}.data(:,9);   %loss
social_context{sub,r}(:,7)=run_{r,sub}.data(:,4);  %gain order
social_context{sub,r}(:,8)=run_{r,sub}.data(:,5);   %loss order
social_context{sub,r}(:,5)=run_{r,sub}.data(:,14)-run_{r,sub}.data(1,18);  %dec onset
social_context{sub,r}(:,6)=run_{r,sub}.data(:,15)-run_{r,sub}.data(1,18);  %outcome  onset
social_context{sub,r}(:,9)=ones(108,1)*r;
end
social_context{sub,4}=[social_context{sub,1};social_context{sub,2};social_context{sub,3}];
social_context{sub,4}(:,10)=[1:324];
social_context{sub,4}(:,11)=ones(324,1)*5;

%Ԥ��p��percentage choose safe������ȱʧֵ
y_pre{sub}=pre(sub,:);
y_pre{sub}(:,find(y_pre{sub}==5))=[];
y_pre{sub}=y_pre{sub}';
N=ismissing(social_context{sub,4}(:,2));%dec
l=find(N==1);
dire{sub}=y_pre{sub}';
for i=1:length(l)%����ȱʧֵ
    dire{sub}=[dire{sub}(1:l(i,1)-1) 6 dire{sub}(l(i,1):end)]; 
end
social_context{sub,4}(:,12)=dire{sub}';

for i=1:4
dec{sub,i}=social_context{sub,4}(find(social_context{sub,4}(:,1)==i),:);
dec_s(sub,i)=1-sum(dec{sub,i}(:,2),1)/length(dec{sub,i}); %  1solo;2Mix;3Ssfe;4Risk    Percentage safe choices 
c=dec{sub,i}(:,12);
c(find(c==6),:)=[];
dec_s_pre(sub,i)=1-mean(c);
end
end

for sub=1:52
a=social_context{sub,4}(find(social_context{sub,4}(:,1)==3),2);
b=social_context{sub,4}(find(social_context{sub,4}(:,1)==4),2);
conformity_S(sub,1)=length(find(a==0))/(81-length(find(isnan(a)==1)));
conformity_R(sub,1)=length(find(b==1))/(81-length(find(isnan(b)==1)));
end

for i=1:52
    lost_list(i,1)=length(find(social_context{i,4}(:,12)==6));
end
    
for sub=1:length(subjects)
for c=1:4      %1solo;2Mix;3Ssfe;4Risk
for i=1:81 %direction matrix
m_dec{sub,c}(dec{sub,c}(i,7),dec{sub,c}(i,8))=dec{sub,c}(i,12);%12����Ԥ��ֵ
m_dec_r{sub,c}(dec{sub,c}(i,7),dec{sub,c}(i,8))=dec{sub,c}(i,2);%2������ʵֵ 
m_order{sub,c}(dec{sub,c}(i,7),dec{sub,c}(i,8))=dec{sub,c}(i,10);
end
end
d_safe(sub,:)=reshape(0-m_dec{sub,1},1,[])';%����distance    1-solo�����µ�Ԥ��p��ѡ�����ѡ��ĸ��ʣ�
d_risk(sub,:)=reshape(1-m_dec{sub,1},1,[])';
order_safe(sub,:)=reshape(m_order{sub,3},1,[]);
order_risk(sub,:)=reshape(m_order{sub,4},1,[]);

m_dec_r{sub,5}=m_dec_r{sub,1}-m_dec_r{sub,3};%solo-safe
m_dec_r{sub,6}=m_dec_r{sub,1}-m_dec_r{sub,4};%solo-risky
conformity_safe(sub,1)=length(find(m_dec_r{sub,5}==1))/81;%real conformity
conformity_risk(sub,1)=length(find(m_dec_r{sub,6}==-1))/81;



%conform trail��Ӧ��mix trial
order_mix(sub,:)=reshape(m_order{sub,2},1,[]);
di_safe(sub,:)=reshape(m_dec_r{sub,3},1,[])';%safe condition decision
di_risk(sub,:)=reshape(m_dec_r{sub,4},1,[])';%risk condition decision
di_mix(sub,:)=reshape(m_dec_r{sub,2},1,[])';%mix condition decision
h=ismissing(di_mix(sub,:));
l_con_mix_s{sub}=order_mix(sub,intersect(find(di_safe(sub,:)==0),find(h==0)));%conform trail��Ӧ��mix trial
l_con_mix_r{sub}=order_mix(sub,intersect(find(di_risk(sub,:)==1),find(h==0)));
l_=zeros(324,1);
l_([l_con_mix_s{sub}';l_con_mix_r{sub}'],1)=1;
social_context{sub,4}(:,13)=l_; 

for i=1:81
social_context{sub,4}(order_safe(sub,i),11)=d_safe(sub,i);
social_context{sub,4}(order_risk(sub,i),11)=d_risk(sub,i);
end

social_context{sub,1}(:,10)=social_context{sub,4}(1:108,11);
social_context{sub,2}(:,10)=social_context{sub,4}(109:216,11);
social_context{sub,3}(:,10)=social_context{sub,4}(217:324,11);
social_context{sub,1}(:,11)=social_context{sub,4}(1:108,13);
social_context{sub,2}(:,11)=social_context{sub,4}(109:216,13);
social_context{sub,3}(:,11)=social_context{sub,4}(217:324,13);
end

%%
for sub=1:length(subjects)

%%
% %Onset����
for r=1:3 %run
 %condition (social context)
a{sub,r}=ismissing(social_context{sub,r}(:,2));
social_context{sub,r}(find(a{sub,r}(:,1)==1),:)=[]; %ɾ��ȱʧtrail
social_context{sub,r}(find(social_context{sub,r}(:,10)==-6),:)=[];%%ɾ��safe(1-6=-5)��risk(0-6=-6)�������Ӧ��ȱʧtrail��ȱʧtrail��solo��
social_context{sub,r}(find(social_context{sub,r}(:,10)==-5),:)=[];

%info trial
l_ss=intersect(find(social_context{sub,r}(:,1)==3),find(social_context{sub,r}(:,2)==0));%�ҵ�info trail�����
l_sr=intersect(find(social_context{sub,r}(:,1)==3),find(social_context{sub,r}(:,2)==1));
l_rr=intersect(find(social_context{sub,r}(:,1)==4),find(social_context{sub,r}(:,2)==1));
l_rs=intersect(find(social_context{sub,r}(:,1)==4),find(social_context{sub,r}(:,2)==0));
condition_info_c{sub}{r,1}=social_context{sub,r}([l_ss;l_rr],5); 
condition_info_nc{sub}{r,1}=social_context{sub,r}([l_sr;l_rs],5); 
condition_solo_mix{sub}{r,1}=social_context{sub,r}([find(social_context{sub,r}(:,1)==1);find(social_context{sub,r}(:,1)==2)],5); 
condition_con_mix{sub}{r,1}=social_context{sub,r}(find(social_context{sub,r}(:,11)==1),5);
condition_mix{sub}{r,1}=social_context{sub,r}(find(social_context{sub,r}(:,1)==2),5); 
condition_solo{sub}{r,1}=social_context{sub,r}(find(social_context{sub,r}(:,1)==1),5); 
for con=1:4% subID rho ocu lambda
    p3{sub}{r,con}=social_context{sub,r}(find(social_context{sub,r}(:,1)==con),3);%gain
    p4{sub}{r,con}=social_context{sub,r}(find(social_context{sub,r}(:,1)==con),4);%loss
    U_safe=0;    %Utility of safe choice
    U_risky{sub}{r,con}=0.5*p3{sub}{r,con}.^par(sub,2)-0.5*par(sub,4)*abs(p4{sub}{r,con}).^par(sub,2);%Utility of risk choice
    if con==3  % safe condition 
    U_ocu_{sub}{r,con}=U_safe+par(sub,3)- U_risky{sub}{r,con};
    elseif con==4 % risky condition 
    U_ocu_{sub}{r,con}=U_safe-(U_risky{sub}{r,con}+par(sub,3));  
    else
    U_ocu_{sub}{r,con}=U_safe - U_risky{sub}{r,con}; 
    end
  U_solo_{sub}{r,con}=U_safe - U_risky{sub}{r,con};   
end 
%conform U_ocu Usolo 
U_ocu_a{sub}{r}=[U_ocu_{sub}{r,1};U_ocu_{sub}{r,2};U_ocu_{sub}{r,3};U_ocu_{sub}{r,4}];
U_solo_a{sub}{r}=[U_solo_{sub}{r,1};U_solo_{sub}{r,2};U_solo_{sub}{r,3};U_solo_{sub}{r,4}];
U_ocu{sub}{r}=U_ocu_a{sub}{r}([l_ss;l_rr],:);
U_solo{sub}{r}=U_solo_a{sub}{r}([l_ss;l_rr],:);
U_ocu{sub}{r}=zscore(U_ocu{sub}{r});
U_solo{sub}{r}=zscore(U_solo{sub}{r});

%direction
%direction{sub}{r}=[social_context{sub,r}(l_ss,10);social_context{sub,r}(l_rr,10)];

% direction{sub}{r}(find(direction{sub}{r}>0),1)=1;%
% direction{sub}{r}(find(direction{sub}{r}==0),1)=0;
% direction{sub}{r}(find(direction{sub}{r}<0),1)=-1;
direction_m{sub}{r}=abs([social_context{sub,r}(l_ss,10);social_context{sub,r}(l_rr,10)]);
direction4{sub}{r}=[-1*ones(length(l_ss),1);ones(length(l_rr),1)];
direction3{sub}{r}=[ones(length(l_ss),1);-1*ones(length(l_rr),1)];
end
end

save condition_direction2.mat U_ocu U_solo condition_info_c condition_info_nc condition_solo_mix direction direction_m
save condition_co_mix.mat condition_mix condition_info_c condition_solo
save condition_info_mix.mat condition_mix condition_info condition_solo
save condition_info2.mat condition_mix condition_info condition_solo U_ocu2 U_solo2
for i=1:length(direction)
    for m=1:3
     a{m,i}=find(direction_m{i}{1,m}==0);
    end 
end

%%
load('condition_direction2.mat')
for i=1:length(condition_info_c)
    for r=1:3
      condition_info_c_risk{i}{r}=condition_info_c{i}{r}(find(direction{i}{r}>0),:); %risk influence
      condition_info_c_safe{i}{r}=condition_info_c{i}{r}(find(direction{i}{r}<0),:); %safe influence
      distance_risk{i}{r}=direction_m{i}{r}(find(direction{i}{r}>0),:); %risk influence
      distance_safe{i}{r}=direction_m{i}{r}(find(direction{i}{r}<0),:); %safe influence
    end
end
save condition_direction_safe_risk.mat
%%
%�����ɵ͵���
lam=par(:,4);
[a,order]=sort(lam);
l1=order(1:13,:);
l2=order(14:26,:);
l3=order(27:39,:);
l4=order(40:52,:);

ttest=[conformity_risk(l1,:),conformity_safe(l1,:),conformity_risk(l2,:),conformity_safe(l2,:),conformity_risk(l3,:),conformity_safe(l3,:),conformity_risk(l4,:),conformity_safe(l4,:)];
ttest_=[conformity_R(l1,:),conformity_S(l1,:),conformity_R(l2,:),conformity_S(l2,:),conformity_R(l3,:),conformity_S(l3,:),conformity_R(l4,:),conformity_S(l4,:)];

%%  conformity risk%/conformity safe%
load condition_direction2.mat direction
for i=1:length(direction)
    con_risk_con_safe(i,1)=(length(find(direction{i}{1}>0))+length(find(direction{i}{2}>0))+length(find(direction{i}{3}>0)))/(length(find(direction{i}{2}<0))+length(find(direction{i}{2}<0))+length(find(direction{i}{3}<0)))
end    
%%  Data stimulation
for i=1:52
    d1=social_context{i,4};
    d1(find(ismissing(d1(:,2))==1),:)=[];
    R(i,1)=corr(d1(:,2),d1(:,12));
    P_safe(i,1)=length(find(d1(:,2)==0))/length(d1);
    P_safe(i,2)=1-mean(d1(:,12))
end
corr(P_safe(:,1),P_safe(:,2))
a1=social_context{1,4}(:,2);
b1=social_context{1,4}(:,12);
for i=1:52-1
    a2=[a1;social_context{i+1,4}(:,2)];
    a1=a2;
    b2=[b1;social_context{i+1,4}(:,12)];
    b1=b2;
end
b1(find(ismissing(a1)==1),:)=[];
a1(find(ismissing(a1)==1),:)=[];
% b1(find(b1>0.5),1)=1;
% b1(find(b1<=0.5),1)=0;
corr(a1,b1)
%
%Figure2a

for i=1:52
  for c=1:4 %1solo;2Mix;3Ssfe;4Risk
      mm1=m_dec{i,c};
      mm2=reshape(mm1,[],1);
      mm2(find(mm2==6),:)=[];
      %mm3(i,c)=length(find(mm2>=0.5))/length(mm2);
      mm3(i,c)=mean(mm2);
  end
end
[t p]=ttest(mm3(:,1),mm3(:,3))
mm3=1-mm3;
mm3=(mm3-mm3(:,1))*100;
mm4=mean(mm3)
mm4=mm4-mm4(1,1);
bar(mm4)
%  Figure 2c
%regression
for i=2:4
    par(:,i)=par(:,i)-mean(par(:,i));
end
[r p]=corr(conformity_risk,par(:,3).*par(:,4))
% anova
lam=par(:,4);
[a,order]=sort(lam);
l1=order(1:13,:);
l2=order(14:26,:);
l3=order(27:39,:);
l4=order(40:52,:);

dec_s_pre(:,4)=1-dec_s_pre(:,4);
t=[dec_s_pre(l1,4),dec_s_pre(l1,3),dec_s_pre(l2,4),dec_s_pre(l2,3),dec_s_pre(l3,4),dec_s_pre(l3,3),dec_s_pre(l4,4),dec_s_pre(l4,3)];


